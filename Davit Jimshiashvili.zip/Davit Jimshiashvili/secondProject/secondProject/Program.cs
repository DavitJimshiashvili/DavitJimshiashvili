﻿using System;

namespace secondProject
{
    class Program
    {
        static void changedArr(int[] arr, int num)
        {

            for (int i=1; i<arr.Length;i++)
            {
                arr[i-1] = arr[i];
                
            }
            for (int j = arr.Length - num; j > 0; j--)
            {
                arr[j] =
                    
           }

        }
        static void Main(string[] args)
        {
            Console.Write("Enter array size: ");
            int arrSize = int.Parse(Console.ReadLine());
            int[] array = new int[arrSize];
            for (int i = 0; i < arrSize; i++)
            {
                Console.Write("Enter number for index"+ i +" ");
                array[i] = int.Parse(Console.ReadLine());
            }
            changedArr(array, 2);

        }
    }
}
