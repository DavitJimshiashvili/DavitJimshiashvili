﻿using System;

namespace firstProject
{
    class Program
    {
        static double Discriminant(int a, int b, int c) 
        {
            double d = b * b - 4 * a * c;
            if (d >= 0)
            {
                return d;
            }
            return -1;
        }
        static double x1(int a, int b, double d)
        {
            return (-b + Math.Sqrt(d)) / (2 * a);
        }
        
        static double x2(int a, int b, double d)
        {
            return (-b - Math.Sqrt(d)) / (2 * a);
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Enter first variable a: ");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter second variable b: ");
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter third variable c: ");
            int c = int.Parse(Console.ReadLine());

            double discriminant=Discriminant(a, b, c);
            Console.WriteLine("x1 = "+ x1(a,b,discriminant));
            Console.WriteLine("x2 = "+x2(a,b,discriminant));
            

        }
    }
}
