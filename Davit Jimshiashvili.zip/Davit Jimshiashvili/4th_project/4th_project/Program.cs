﻿using System;

namespace _4th_project
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Calculator");
            Console.WriteLine( "Enter first number: " );
            double firstNum = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter operation { + or - or * or / or ^ or root}");
            string operation = Console.ReadLine();
            Console.WriteLine("Enter second number: ");
            double secondNum = double.Parse(Console.ReadLine());

            switch (operation)
            {
                case "+":
                    Console.WriteLine(firstNum+secondNum);
                    break;
                case "-":
                    Console.WriteLine(firstNum - secondNum);
                    break;
                case "*":
                    Console.WriteLine(firstNum * secondNum);
                    break;
                case "/":
                    Console.WriteLine(firstNum / secondNum);
                    break;
                case "^":
                    Console.WriteLine(Math.Pow(firstNum,secondNum));
                    break;
                case "root":
                    Console.WriteLine(Math.Pow(firstNum,1/secondNum));
                    break;

                default: Console.WriteLine("wrong operation ");
                    break;


            }
        }
    }
}
