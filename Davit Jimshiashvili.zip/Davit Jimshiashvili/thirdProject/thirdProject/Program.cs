﻿using System;
using System.IO;

namespace thirdProject
{
    class Program
    {
        static void printRecur(string dir)
        {
            string[] dirArr = Directory.GetDirectories(dir);
            foreach (var item in dirArr)
            {
               
                Console.WriteLine(item);
            }




        }
        
        static void Main(string[] args)
        {
            Console.WriteLine("To turn off program type \"exit\" otherwise enter the directory path ");
            string condition="";
            bool existance = true;
            string directory;
            while (condition != "exit")
            {
                if (condition != "exit") {
                    Console.WriteLine("enter directory adress: ");
                    directory = Console.ReadLine();
                    existance = Directory.Exists((directory));
                    if (!existance)
                    {
                        Console.WriteLine("The directory " + directory + "does not exist!");
                    }
                    else printRecur(directory);
                }

                Console.WriteLine("write exit to close program: ");
                condition = Console.ReadLine();
            }
        }
    }
}
